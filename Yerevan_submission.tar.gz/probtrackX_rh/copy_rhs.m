% Here we copy all rhs matrices into one folder.

folder = '/data/pt_nps167/connectivity/results/yr';
folder2 = '/probtrackX_rh/fdt_network_matrix';
folder3 = '/data/tu_hschmidt/myDocuments/MATLAB/Yerevan/probtrackX_rh/yr';
folder4 = '/fdt_network_matrix';

% subs = setdiff([1:30],[23,28]); % vector with subject numbers;
subs = [1:30];
Nsub = numel(subs); % number of subjects;
str(1) = 'a'; str(2) = 'b'; str(3) = 'c'; % string snippets for file names;

SC = NaN(N2^2,28*3); % data array = matrix M;
nodeind = setdiff([1:N2],89);

% load data:
for m = 1:Nsub
    for n = 1:2
        if m<10
            numstr = strcat('0',num2str(subs(m)));
        else
            numstr = num2str(subs(m));
        end
%         A = load(strcat(folder,numstr,str(n),folder2));
        strt = convertStringsToChars(strcat('yr',numstr,str(n)));
        mkdir(strt);
        str1 = strcat(folder,numstr,str(n),folder2);
        str2 = strcat(folder3,numstr,str(n),folder4);
        copyfile(str1,str2);
    end
end