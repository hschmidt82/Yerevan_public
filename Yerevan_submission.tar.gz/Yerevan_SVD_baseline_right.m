% Perform SVD on Yerevan data

close all; 
clear all;

N2 = 185;

% folder for connectivity data:
folder = 'probtrackX_rh/';
filen = '/fdt_network_matrix';

subs = setdiff([1:30],[23,28]); % vector with subject numbers;
Nsub = numel(subs); % number of subjects;
str(1) = 'a'; str(2) = 'b'; str(3) = 'c'; % string snippets for file names;

SC = NaN(N2^2,Nsub*3); % data array = matrix M;

% load data:
for m = 1:Nsub
    for n = 1:2
        if m<10
            numstr = strcat('0',num2str(subs(m)));
        else
            numstr = num2str(subs(m));
        end
        A = load(strcat(folder,'yr',numstr,str(n),filen));
        SC(:,m+(n-1)*Nsub) = A(:);
    end
end

% perform SVD:
[uq,sq,vq] = svd(SC(:,1:Nsub),'econ');

% load performance data:
perf1 = readtable('yerevan_performance_for_Helmut.csv'); 
% select specific performance markers:
% 8  = firstTryPerformance;
% 9  = totalPerformance;
% 12 = singleFirstTryPerformance;
% 15 = doubleFirstTryPerformance;
perf2 = table2array(perf1(:,[8,9,12,15]));

% arrange performance markers into 2D array:
for m = 1:4
    perf3(:,1+10*(m-1)) = perf2(4*subs-3,m); % performance day1;
    perf3(:,2+10*(m-1)) = perf2(4*subs-2,m); % performance day2;
    perf3(:,3+10*(m-1)) = perf2(4*subs-1,m); % performance day3;
    perf3(:,4+10*(m-1)) = perf2(4*subs,m);   % performance day4;
    perf3(:,5+10*(m-1)) = perf2(4*subs-2,m)-perf2(4*subs-3,m); % day2 - day1;
    perf3(:,6+10*(m-1)) = perf2(4*subs-1,m)-perf2(4*subs-3,m); % day3 - day1;
    perf3(:,7+10*(m-1)) = perf2(4*subs-1,m)-perf2(4*subs-2,m); % day3 - day2;
    perf3(:,8+10*(m-1)) = perf2(4*subs,m)-perf2(4*subs-3,m);   % day4 - day1;
    perf3(:,9+10*(m-1)) = perf2(4*subs,m)-perf2(4*subs-2,m);   % day4 - day2;
    perf3(:,10+10*(m-1)) = perf2(4*subs,m)-perf2(4*subs-1,m);  % day4 - day3;
end

% indices for performance markers on day1:
indp = 31;

% test correlation of loadings with performances on day1:
for m = 1:numel(indp)
    for n = 1:Nsub
        [r(m,n),p(m,n)] = corr(vq(:,n),perf3(:,indp(m)),'type','Spearman');
    end
end

LC = -0.5.*reshape(uq(:,7),[N2 N2])-0.5.*reshape(uq(:,7),[N2 N2])';
ROI = readtable('ROI_COOERDINATE__TABLE.csv'); % load coordinates for ROIs
lm = fitlm(perf3(:,31),-vq(:,7))
figure; plot(perf3(:,31),-vq(:,7),'.','MarkerSize',10,'Color',[0 84 95]./255); hold on; 
line([0.55 0.95],-[0.55 0.95].*1.1807+0.867,'LineWidth',2);

indmust = [37 116 120 122 126 139 160 163 166 169];
indplot = find(sum((abs(LC)>0))>0);
NN = 10;
thr = 0.0001;
while NN==10
    thr = thr+0.0001;
    indplot = find(sum((abs(LC)>thr))>0);
    NN = numel(intersect(indmust,indplot));
end
indplot = find(sum((abs(LC)>thr-0.001))>0);

% Glasser regions:
GS{1} = 163;
GS{2} = [165 169 170];
GS{3} = [173 166 174 88 167 172];
GS{4} = [175 71 130 177 179 178 180];
GS{5} = [98 92 93 99 126 171 77 168 94];
GS{6} = [27 19 7 13 18 37];
GS{7} = [31 32 8 30 10 11 143 35 36];
GS{8} = [70 114 29 34 38 33];
GS{9} = [20 101 102 103 72];
GS{10} = [55 28 139 115 111 95 89];
GS{11} = [151 145 61 146 147 148 149 60];
GS{12} = [133 75 97 129 65 63 74 73 132 84 76 128];
GS{13} = [69 136 78 113 123 124 125 157];
GS{14} = [158 152 154 155 156 127 159 153];
GS{15} = [138 150 160 161 162];
GS{16} = [44 39 40 43 42 91 176 96 90 64];
GS{17} = [119 121 85 86 87 117 118 116 120 122];
GS{18} = [140 135 112 41 134 9 164 66 16 137 68 15 14];
GS{19} = [105 17 56 107 57 67 48 3 52 4 12 141 131 58 106 108];
GS{20} = [25 1 54 2 5 6 100 26 104];
GS{21} = [21 22 24 59 80 81 82 83 109];
GS{22} = [144 46 45 47 53 49 110 23 62 50 51 79 142];

% Colours:
GC{1} = [228 184 180]./255;
GC{2} = [206 128 128]./255;
GC{3} = [81 29 36]./255;
GC{4} = [241 182 130]./255;
GC{5} = [255 223 118]./255;
GC{6} = [171 180 125]./255;
GC{7} = [163 2 52]./255;
GC{8} = [103 119 26]./255;
GC{9} = [161 187 203]./255;
GC{10} = [0 118 192]./255;
GC{11} = [0 33 87]./255;
GC{12} = [227 124 29]./255;
GC{13} = [122 80 114]./255;
GC{14} = [44 51 56]./255;
GC{15} = [0 84 95]./255;
GC{16} = [100 105 112]./255;
GC{17} = [167 170 173]./255;
GC{18} = [86 152 163]./255;
GC{19} = [0 47 48]./255;
GC{20} = [74 50 0]./255;
GC{21} = [189 134 0]./255;
GC{22} = [0 69 12]./255;

% reduced colour scheme:
GC2{1} = [206 128 128]./255;
GC2{2} = [241 182 130]./255;
GC2{3} = [255 223 118]./255;
GC2{4} = [171 180 125]./255;
GC2{5} = [163 2 52]./255;
GC2{6} = [103 119 26]./255;
GC2{7} = [161 187 203]./255;
GC2{8} = [0 118 192]./255;
GC2{9} = [0 33 87]./255;
GC2{10} = [227 124 29]./255;
GC2{11} = [122 80 114]./255;
GC2{12} = [44 51 56]./255;
GC2{13} = [0 84 95]./255;
GC2{14} = [100 105 112]./255;
GC2{15} = [167 170 173]./255;
GC2{16} = [86 152 163]./255;
GC2{17} = [0 47 48]./255;
GC2{18} = [74 50 0]./255;
GC2{19} = [189 134 0]./255;
GC2{20} = [0 69 12]./255;

% colour scheme rhs
GCR{8} = [0.2 0.13 0.53];
GCR{10} = [0.53 0.8 0.93];
GCR{9} = [0.27 0.67 0.6];
GCR{1} = [0.07 0.47 0.2];
GCR{6} = [0.6 0.6 0.2];
GCR{5} = [0.87 0.8 0.47];
GCR{7} = [0.8 0.4 0.47];
GCR{2} = [0.53 0.13 0.33];
GCR{3} = [0.67 0.27 0.6];
GCR{4} = [0.93 0.47 0.2];

indplot2 = [];
for m = 1:22
    aid = intersect(indplot,GS{m});
    indplot2 = cat(2,indplot2,aid);
    numS(m) = numel(aid);
end
indplot = indplot2;

z = [0:100]./100;

figure;
plotcolor2 = zeros(numel(indplot),1);
for m = 1:numel(indplot)
% for m = 1:2
    thet0 = 2*pi*(m-3/2)/numel(indplot);
    thet1 = 2*pi*(m-1/2)/numel(indplot);
    plotcolor = GC{17};
    if ~isempty(intersect(indplot(m),indmust))
        [~,plotind] = find(indmust==indplot(m));
        plotcolor = GCR{plotind};
        plotcolor2(m) = plotind;
    end
    plot(-cos(thet0 + (thet1-thet0).*z),-sin(thet0 + (thet1-thet0).*z),'Color',plotcolor,'LineWidth',10);  hold on;
end
pbaspect([1 1 1])

for m = 1:numel(indplot); mylabel{m} = ''; mylabel2{m} = strip(table2array(ROI(indplot(m),5)),'left','L'); end
f = figure; circularGraph(abs(LC(indplot,indplot)).*(LC(indplot,indplot)<-0.03),'Colormap',repmat([0.85 0.25 0.15],[numel(indplot) 1]),'label',mylabel);
hold on; circularGraph(abs(LC(indplot,indplot)).*(LC(indplot,indplot)>0.03),'Colormap',repmat([0.15 0.25 0.65],[numel(indplot) 1]),'label',mylabel2);
set(f,'renderer','painters')

% END OF FILE